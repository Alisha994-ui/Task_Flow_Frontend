import '../core/network/api_client.dart';
import '../core/network/api_parsing.dart';
import '../models/assistant_message_model.dart';

/// The in-app assistant. Everything about the model, the key and the
/// prompt lives on the server - this only asks and listens.
class AssistantService {
  static Future<List<AssistantMessageModel>> getThread() async {
    final dynamic response = await ApiClient.get('/assistant/');

    return extractResults(response)
        .map(AssistantMessageModel.fromJson)
        .toList();
  }

  /// How long to wait before giving up.
  ///
  /// The model is usually quick, but a busy one has left the app on a
  /// spinner for over two minutes with no way out. Better a clear
  /// failure after 45 seconds than an unbounded wait.
  static const Duration _patience = Duration(seconds: 45);

  /// Returns the answer's text.
  static Future<String> ask(String question) async {
    final response = await ApiClient.post(
      '/assistant/ask/',
      body: <String, dynamic>{'question': question},
    ).timeout(
      _patience,
      onTimeout: () => throw Exception(
        "The assistant didn't answer in time. Try asking again.",
      ),
    );

    return response['answer']?.toString() ?? '';
  }

  static Future<void> clear() async {
    await ApiClient.post('/assistant/clear/');
  }
}
