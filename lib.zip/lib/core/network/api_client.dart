import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../storage/secure_storage.dart';

class ApiClient {
  ApiClient._();

  // ============================================================
  // BASE URL
  // ============================================================

  static const String baseUrl =
      'http://192.168.18.180:8000/api';

  /// Where a spent access token is exchanged for a fresh one.
  ///
  /// CHECK THIS against your own urls.py. Login is /auth/login/, so
  /// this is the usual neighbour - but SimpleJWT's own route is
  /// /auth/token/refresh/. If refreshing never works, this is the first
  /// line to look at.
  static const String refreshEndpoint = '/auth/refresh/';

  static final SecureStorage _storage =
      SecureStorage();

  /// Held while a refresh is in flight, so two requests failing at the
  /// same moment wait on one refresh instead of racing each other.
  static Future<bool>? _refreshing;

  /// True once the refresh token is gone or rejected - the point where
  /// the person really does have to sign in again.
  static bool sessionExpired = false;

  // ============================================================
  // GET
  // ============================================================

  static Future<Map<String, dynamic>> get(
    String endpoint, {
    bool authenticated = true,
  }) async {
    final response = await _send(
      (headers) => http.get(
        Uri.parse('$baseUrl$endpoint'),
        headers: headers,
      ),
      authenticated,
    );

    return _handleResponse(response);
  }

  // ============================================================
  // POST
  // ============================================================

  static Future<Map<String, dynamic>> post(
    String endpoint, {
    Map<String, dynamic>? body,
    bool authenticated = true,
  }) async {
    final response = await _send(
      (headers) => http.post(
        Uri.parse('$baseUrl$endpoint'),
        headers: headers,
        body: body == null ? null : jsonEncode(body),
      ),
      authenticated,
    );

    return _handleResponse(response);
  }

  // ============================================================
  // PATCH
  // ============================================================

  static Future<Map<String, dynamic>> patch(
    String endpoint, {
    Map<String, dynamic>? body,
    bool authenticated = true,
  }) async {
    final response = await _send(
      (headers) => http.patch(
        Uri.parse('$baseUrl$endpoint'),
        headers: headers,
        body: body == null ? null : jsonEncode(body),
      ),
      authenticated,
    );

    return _handleResponse(response);
  }

  // ============================================================
  // DELETE
  // ============================================================

  static Future<void> delete(
    String endpoint, {
    bool authenticated = true,
  }) async {
    final response = await _send(
      (headers) => http.delete(
        Uri.parse('$baseUrl$endpoint'),
        headers: headers,
      ),
      authenticated,
    );

    if (response.statusCode >= 200 &&
        response.statusCode < 300) {
      return;
    }

    dynamic decoded;

    try {
      if (response.body.isNotEmpty) {
        decoded = jsonDecode(response.body);
      }
    } catch (_) {
      decoded = null;
    }

    if (decoded is Map<String, dynamic>) {
      throw Exception(
        decoded['detail']?.toString() ??
            decoded['message']?.toString() ??
            'Delete failed (${response.statusCode})',
      );
    }

    throw Exception(
      'Delete failed (${response.statusCode})',
    );
  }

  // ============================================================
  // MULTIPART POST (file upload)
  // ============================================================

  static Future<Map<String, dynamic>> postMultipart(
    String endpoint, {
    required String filePath,
    String fileField = 'file',
    Map<String, String> fields = const <String, String>{},
    bool authenticated = true,
  }) async {
    Future<http.Response> attempt(Map<String, String> headers) async {
      final request = http.MultipartRequest(
        'POST',
        Uri.parse('$baseUrl$endpoint'),
      );

      // MultipartRequest writes its own Content-Type with a boundary,
      // so the JSON one has to go.
      final multipartHeaders = Map<String, String>.from(headers)
        ..remove('Content-Type');

      request.headers.addAll(multipartHeaders);
      request.fields.addAll(fields);

      request.files.add(
        await http.MultipartFile.fromPath(
          fileField,
          filePath,
        ),
      );

      final streamed = await request.send();

      return http.Response.fromStream(streamed);
    }

    final response = await _send(attempt, authenticated);

    return _handleResponse(response);
  }

  // ============================================================
  // SENDING, WITH ONE SILENT RETRY
  // ============================================================

  /// Runs [attempt]. If the server rejects the access token, refreshes
  /// it once and runs [attempt] again.
  ///
  /// This is what keeps somebody signed in until they choose to sign
  /// out: the access token stays short-lived, and the refresh token
  /// quietly replaces it in the background.
  static Future<http.Response> _send(
    Future<http.Response> Function(Map<String, String> headers) attempt,
    bool authenticated,
  ) async {
    late http.Response response;

    try {
      response = await attempt(await _headers(authenticated));
    } catch (e) {
      // "ClientException with SocketException: No route to host, errno
      // = 113, uri=http://192.168..." means nothing to a person and
      // puts the server's address on their screen.
      throw Exception(_networkMessage(e));
    }

    if (response.statusCode != 401 || !authenticated) {
      return response;
    }

    final bool refreshed = await _refreshAccessToken();

    if (!refreshed) {
      return response;
    }

    try {
      return await attempt(await _headers(authenticated));
    } catch (e) {
      throw Exception(_networkMessage(e));
    }
  }

  /// Turns a transport failure into something worth reading. The detail
  /// goes to the log, where it belongs.
  static String _networkMessage(Object error) {
    debugPrint('Network error: $error');

    final String text = error.toString();

    if (text.contains('TimeoutException')) {
      return 'The server took too long to answer. Try again.';
    }

    if (text.contains('SocketException') ||
        text.contains('ClientException') ||
        text.contains('No route to host') ||
        text.contains('Network is unreachable') ||
        text.contains('Failed host lookup') ||
        text.contains('Connection refused')) {
      return "Can't reach the server. Check your connection and try again.";
    }

    return 'Something went wrong. Try again.';
  }

  /// Swaps the refresh token for a new access token.
  ///
  /// False means there was nothing to refresh with, or the refresh
  /// token has itself expired.
  static Future<bool> _refreshAccessToken() async {
    final inFlight = _refreshing;

    if (inFlight != null) {
      return inFlight;
    }

    final completer = Completer<bool>();
    _refreshing = completer.future;

    try {
      final refreshToken = await _storage.getRefreshToken();

      if (refreshToken == null || refreshToken.isEmpty) {
        sessionExpired = true;
        completer.complete(false);

        return false;
      }

      final response = await http.post(
        Uri.parse('$baseUrl$refreshEndpoint'),
        headers: const {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: jsonEncode({'refresh': refreshToken}),
      );

      if (response.statusCode < 200 || response.statusCode >= 300) {
        // The refresh token is spent. Clear everything, or the app
        // keeps retrying with credentials that cannot work.
        await _storage.clearTokens();
        sessionExpired = true;
        completer.complete(false);

        return false;
      }

      final decoded = jsonDecode(response.body);

      if (decoded is! Map<String, dynamic>) {
        sessionExpired = true;
        completer.complete(false);

        return false;
      }

      final access = decoded['access']?.toString();

      if (access == null || access.isEmpty) {
        sessionExpired = true;
        completer.complete(false);

        return false;
      }

      // With ROTATE_REFRESH_TOKENS on, the reply carries a new refresh
      // token as well; without it, keep the one already held.
      final newRefresh =
          decoded['refresh']?.toString() ?? refreshToken;

      await _storage.saveTokens(
        accessToken: access,
        refreshToken: newRefresh,
      );

      sessionExpired = false;
      completer.complete(true);

      return true;
    } catch (_) {
      // A dropped connection is not an expired session - do not throw
      // the person out over it.
      completer.complete(false);

      return false;
    } finally {
      _refreshing = null;
    }
  }

  // ============================================================
  // HEADERS
  // ============================================================

  static Future<Map<String, String>> _headers(
    bool authenticated,
  ) async {
    final headers = <String, String>{
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };

    if (authenticated) {
      final token =
          await _storage.getAccessToken();

      if (token != null && token.isNotEmpty) {
        headers['Authorization'] =
            'Bearer $token';
      }
    }

    return headers;
  }

  // ============================================================
  // MEDIA URLS
  // ============================================================

  /// The server without the trailing /api, so uploaded files resolve.
  ///   baseUrl     http://192.168.18.180:8000/api
  ///   serverRoot  http://192.168.18.180:8000
  static String get serverRoot {
    if (baseUrl.endsWith('/api')) {
      return baseUrl.substring(
        0,
        baseUrl.length - 4,
      );
    }

    return baseUrl;
  }

  /// Django may return a full URL or a path such as
  /// /media/task_attachments/spec.pdf - this makes both openable.
  static String absoluteUrl(String pathOrUrl) {
    if (pathOrUrl.startsWith('http://') ||
        pathOrUrl.startsWith('https://')) {
      return pathOrUrl;
    }

    if (pathOrUrl.startsWith('/')) {
      return '$serverRoot$pathOrUrl';
    }

    return '$serverRoot/$pathOrUrl';
  }

  // ============================================================
  // RESPONSE HANDLER
  // ============================================================

  static Map<String, dynamic> _handleResponse(
    http.Response response,
  ) {
    dynamic decoded;

    try {
      if (response.body.isNotEmpty) {
        decoded = jsonDecode(response.body);
      } else {
        decoded = <String, dynamic>{};
      }
    } catch (_) {
      decoded = {
        'detail': response.body,
      };
    }

    // ----------------------------------------------------------
    // SUCCESS
    // ----------------------------------------------------------

    if (response.statusCode >= 200 &&
        response.statusCode < 300) {
      if (decoded is Map<String, dynamic>) {
        return decoded;
      }

      return {
        'data': decoded,
      };
    }

    // ----------------------------------------------------------
    // ERROR
    // ----------------------------------------------------------

    // A 401 that survived the retry means the refresh token is gone
    // too. Say so plainly rather than showing a JWT message.
    if (response.statusCode == 401) {
      throw Exception(
        'Your session has ended. Please sign in again.',
      );
    }

    if (decoded is Map<String, dynamic>) {
      throw Exception(
        decoded['detail']?.toString() ??
            decoded['message']?.toString() ??
            _extractValidationError(decoded) ??
            'Request failed (${response.statusCode})',
      );
    }

    throw Exception(
      'Request failed (${response.statusCode})',
    );
  }

  // ============================================================
  // VALIDATION ERROR HANDLER
  // ============================================================

  static String? _extractValidationError(
    Map<String, dynamic> data,
  ) {
    final errors = <String>[];

    for (final entry in data.entries) {
      final value = entry.value;

      if (value is List && value.isNotEmpty) {
        errors.add(
          '${entry.key}: ${value.first}',
        );
      } else if (value is String) {
        errors.add(
          '${entry.key}: $value',
        );
      }
    }

    if (errors.isEmpty) {
      return null;
    }

    return errors.join('\n');
  }
}
