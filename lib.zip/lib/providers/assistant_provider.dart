import 'package:flutter/foundation.dart';

import '../models/assistant_message_model.dart';
import '../services/assistant_service.dart';

class AssistantProvider extends ChangeNotifier {
  List<AssistantMessageModel> _messages = <AssistantMessageModel>[];
  bool _isLoading = false;
  bool _isThinking = false;
  String? _error;

  List<AssistantMessageModel> get messages =>
      List<AssistantMessageModel>.unmodifiable(_messages);

  bool get isLoading => _isLoading;

  /// True between sending a question and the answer arriving.
  bool get isThinking => _isThinking;

  String? get error => _error;

  Future<void> load() async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      _messages = await AssistantService.getThread();
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Returns null on success, or something to show the person.
  Future<String?> ask(String question) async {
    final String text = question.trim();

    if (text.isEmpty || _isThinking) {
      return null;
    }

    // Show the question immediately. Waiting for the round trip makes
    // the app feel broken on a slow connection.
    _messages = <AssistantMessageModel>[
      ..._messages,
      AssistantMessageModel.pending(text),
    ];
    _isThinking = true;
    _error = null;
    notifyListeners();

    try {
      final String answer = await AssistantService.ask(text);

      _messages = <AssistantMessageModel>[
        ..._messages,
        AssistantMessageModel(
          id: -2,
          role: 'assistant',
          text: answer,
          createdAt: DateTime.now(),
        ),
      ];

      return null;
    } catch (e) {
      // Drop the optimistic question - it never reached the server, and
      // leaving it there suggests it did.
      _messages = _messages
          .where((AssistantMessageModel m) => m.id != -1)
          .toList();
      _error = e.toString();

      return _friendly(e.toString());
    } finally {
      _isThinking = false;
      notifyListeners();
    }
  }

  Future<void> clear() async {
    try {
      await AssistantService.clear();
      _messages = <AssistantMessageModel>[];
      _error = null;
    } catch (e) {
      _error = e.toString();
    }

    notifyListeners();
  }

  void reset() {
    _messages = <AssistantMessageModel>[];
    _isLoading = false;
    _isThinking = false;
    _error = null;
    notifyListeners();
  }

  String _friendly(String raw) {
    final String message = raw.replaceFirst('Exception: ', '');

    if (message.contains('not configured')) {
      return 'The assistant is not set up on the server yet.';
    }

    return message;
  }
}
